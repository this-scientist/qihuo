# -*- coding: utf-8 -*-

"""
中国商品期货 / 商品期权 数据获取程序

数据源：Tushare Pro
用途：
1. 期货合约信息
2. 真实月份合约日线
3. 主力/连续合约映射
4. 复权主连行情
5. 仓单数据
6. 持仓排名
7. 每日结算参数
8. 商品期权合约
9. 商品期权日线
"""

import time
import logging
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd
import tushare as ts

from config import (
    TUSHARE_TOKEN,
    TUSHARE_HTTP_URL,
    COMMODITY_EXCHANGES,
    BASIC_DIR,
    DAILY_DIR,
    CONTINUOUS_DIR,
    MAPPING_DIR,
    HOLDING_DIR,
    WAREHOUSE_DIR,
    SETTLE_DIR,
    OPTION_DIR,
    LOG_DIR,
    create_dirs,
)

create_dirs()

log_file = LOG_DIR / "fetch.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(log_file, encoding="utf-8"),
        logging.StreamHandler(),
    ],
)

logger = logging.getLogger(__name__)

token = TUSHARE_TOKEN
pro = ts.pro_api(token)

# 用户指定的两行
pro._DataApi__token = token
pro._DataApi__http_url = TUSHARE_HTTP_URL


def safe_api_call(api_func, retry=3, sleep_seconds=1, **kwargs):
    for i in range(retry):
        try:
            df = api_func(**kwargs)
            if df is None:
                return pd.DataFrame()
            return df
        except Exception as e:
            logger.warning(
                "API调用失败，第 %s/%s 次 | 参数=%s | %s",
                i + 1, retry, kwargs, e
            )
            time.sleep(sleep_seconds * (i + 1))

    logger.error("API调用最终失败：%s", kwargs)
    return pd.DataFrame()


def save_csv(df, file_path):
    if df is None or df.empty:
        return

    file_path = Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)

    df.to_csv(file_path, index=False, encoding="utf-8-sig")

    logger.info("保存：%s | %s 行", file_path, len(df))


def append_unique_csv(df, file_path, subset=None):
    if df is None or df.empty:
        return

    file_path = Path(file_path)

    if file_path.exists():
        try:
            old_df = pd.read_csv(file_path, dtype=str)
            df = df.astype(str)
            df = pd.concat([old_df, df], ignore_index=True)
        except Exception as e:
            logger.warning("读取历史文件失败：%s | %s", file_path, e)

    if subset:
        usable_subset = [x for x in subset if x in df.columns]
        if usable_subset:
            df = df.drop_duplicates(subset=usable_subset, keep="last")
    else:
        df = df.drop_duplicates()

    if "trade_date" in df.columns:
        df = df.sort_values("trade_date")

    save_csv(df, file_path)


def date_range(start_date, end_date):
    start = datetime.strptime(start_date, "%Y%m%d")
    end = datetime.strptime(end_date, "%Y%m%d")

    current = start
    while current <= end:
        yield current.strftime("%Y%m%d")
        current += timedelta(days=1)


def fetch_trade_calendar(start_date, end_date):
    logger.info("开始获取交易日历 %s - %s", start_date, end_date)

    df = safe_api_call(
        pro.trade_cal,
        exchange="SSE",
        start_date=start_date,
        end_date=end_date,
        is_open="1",
    )

    if df.empty:
        return []

    return df["cal_date"].astype(str).tolist()


def fetch_fut_basic():
    all_data = []

    for exchange in COMMODITY_EXCHANGES:
        logger.info("获取期货合约：%s", exchange)

        df = safe_api_call(
            pro.fut_basic,
            exchange=exchange,
        )

        if not df.empty:
            all_data.append(df)
            save_csv(df, BASIC_DIR / f"fut_basic_{exchange}.csv")

        time.sleep(0.3)

    if not all_data:
        return pd.DataFrame()

    result = pd.concat(all_data, ignore_index=True)
    save_csv(result, BASIC_DIR / "fut_basic_all.csv")

    return result


def fetch_fut_daily_by_date(trade_date):
    all_data = []

    for exchange in COMMODITY_EXCHANGES:
        logger.info("%s | 获取 %s 行情", trade_date, exchange)

        df = safe_api_call(
            pro.fut_daily,
            trade_date=trade_date,
            exchange=exchange,
        )

        if not df.empty:
            all_data.append(df)

        time.sleep(0.25)

    if not all_data:
        return pd.DataFrame()

    result = pd.concat(all_data, ignore_index=True)
    save_csv(result, DAILY_DIR / f"{trade_date}.csv")

    return result


def fetch_fut_daily_range(start_date, end_date):
    trade_dates = fetch_trade_calendar(start_date, end_date)

    logger.info("共 %s 个交易日", len(trade_dates))

    for index, trade_date in enumerate(trade_dates, start=1):
        file_path = DAILY_DIR / f"{trade_date}.csv"

        if file_path.exists():
            logger.info(
                "[%s/%s] 已存在，跳过 %s",
                index, len(trade_dates), trade_date
            )
            continue

        logger.info(
            "[%s/%s] 下载 %s",
            index, len(trade_dates), trade_date
        )

        fetch_fut_daily_by_date(trade_date)
        time.sleep(0.5)


def fetch_fut_mapping(start_date, end_date):
    logger.info("获取主力合约映射：%s - %s", start_date, end_date)

    trade_dates = fetch_trade_calendar(start_date, end_date)

    for i, trade_date in enumerate(trade_dates, start=1):
        file_path = MAPPING_DIR / f"{trade_date}.csv"

        if file_path.exists():
            logger.info("mapping 已存在 %s", trade_date)
            continue

        df = safe_api_call(
            pro.fut_mapping,
            trade_date=trade_date,
        )

        if not df.empty:
            save_csv(df, file_path)

        logger.info(
            "mapping %s/%s %s",
            i, len(trade_dates), trade_date
        )

        time.sleep(0.3)


def fetch_fut_daily_adj_by_date(trade_date):
    all_data = []

    for exchange in COMMODITY_EXCHANGES:
        logger.info("%s | 复权主连 %s", trade_date, exchange)

        df = safe_api_call(
            pro.fut_daily_adj,
            trade_date=trade_date,
            exchange=exchange,
        )

        if not df.empty:
            all_data.append(df)

        time.sleep(0.25)

    if not all_data:
        return pd.DataFrame()

    result = pd.concat(all_data, ignore_index=True)
    save_csv(result, CONTINUOUS_DIR / f"{trade_date}.csv")

    return result


def fetch_fut_daily_adj_range(start_date, end_date):
    trade_dates = fetch_trade_calendar(start_date, end_date)

    for i, trade_date in enumerate(trade_dates, start=1):
        file_path = CONTINUOUS_DIR / f"{trade_date}.csv"

        if file_path.exists():
            continue

        logger.info(
            "主连复权 %s/%s | %s",
            i, len(trade_dates), trade_date
        )

        fetch_fut_daily_adj_by_date(trade_date)
        time.sleep(0.4)


def fetch_fut_wsr(start_date, end_date):
    trade_dates = fetch_trade_calendar(start_date, end_date)

    for i, trade_date in enumerate(trade_dates, start=1):
        file_path = WAREHOUSE_DIR / f"{trade_date}.csv"

        if file_path.exists():
            continue

        logger.info(
            "仓单 %s/%s | %s",
            i, len(trade_dates), trade_date
        )

        df = safe_api_call(
            pro.fut_wsr,
            trade_date=trade_date,
        )

        if not df.empty:
            save_csv(df, file_path)

        time.sleep(0.4)


def fetch_fut_holding(start_date, end_date):
    trade_dates = fetch_trade_calendar(start_date, end_date)

    for i, trade_date in enumerate(trade_dates, start=1):
        file_path = HOLDING_DIR / f"{trade_date}.csv"

        if file_path.exists():
            continue

        logger.info(
            "持仓排名 %s/%s | %s",
            i, len(trade_dates), trade_date
        )

        day_data = []

        for exchange in COMMODITY_EXCHANGES:
            df = safe_api_call(
                pro.fut_holding,
                trade_date=trade_date,
                exchange=exchange,
            )

            if not df.empty:
                day_data.append(df)

            time.sleep(0.25)

        if day_data:
            result = pd.concat(day_data, ignore_index=True)
            save_csv(result, file_path)


def fetch_fut_settle(start_date, end_date):
    trade_dates = fetch_trade_calendar(start_date, end_date)

    for i, trade_date in enumerate(trade_dates, start=1):
        file_path = SETTLE_DIR / f"{trade_date}.csv"

        if file_path.exists():
            continue

        logger.info(
            "结算参数 %s/%s | %s",
            i, len(trade_dates), trade_date
        )

        day_data = []

        for exchange in COMMODITY_EXCHANGES:
            df = safe_api_call(
                pro.fut_settle,
                trade_date=trade_date,
                exchange=exchange,
            )

            if not df.empty:
                day_data.append(df)

            time.sleep(0.25)

        if day_data:
            result = pd.concat(day_data, ignore_index=True)
            save_csv(result, file_path)


def fetch_option_basic():
    logger.info("开始获取商品期权基础信息")

    all_data = []

    for exchange in COMMODITY_EXCHANGES:
        try:
            df = safe_api_call(
                pro.opt_basic,
                exchange=exchange,
            )

            if not df.empty:
                all_data.append(df)
                save_csv(
                    df,
                    OPTION_DIR / f"opt_basic_{exchange}.csv",
                )

        except Exception as e:
            logger.warning(
                "%s 期权基础信息失败：%s",
                exchange, e
            )

        time.sleep(0.3)

    if not all_data:
        return pd.DataFrame()

    result = pd.concat(all_data, ignore_index=True)
    save_csv(result, OPTION_DIR / "opt_basic_all.csv")

    return result


def fetch_option_daily_by_date(trade_date):
    logger.info("商品期权行情：%s", trade_date)

    df = safe_api_call(
        pro.opt_daily,
        trade_date=trade_date,
    )

    if df.empty:
        return df

    save_csv(
        df,
        OPTION_DIR / "daily" / f"{trade_date}.csv",
    )

    return df


def fetch_option_daily_range(start_date, end_date):
    trade_dates = fetch_trade_calendar(start_date, end_date)

    for i, trade_date in enumerate(trade_dates, start=1):
        file_path = OPTION_DIR / "daily" / f"{trade_date}.csv"

        if file_path.exists():
            continue

        logger.info(
            "期权日线 %s/%s | %s",
            i, len(trade_dates), trade_date
        )

        fetch_option_daily_by_date(trade_date)
        time.sleep(0.5)


def init_database():
    logger.info("=" * 60)
    logger.info("初始化期货数据库")
    logger.info("=" * 60)

    fetch_fut_basic()
    fetch_option_basic()

    logger.info("基础数据库初始化完成")


def download_history(
    start_date,
    end_date,
    download_daily=True,
    download_adj=True,
    download_mapping=True,
    download_wsr=True,
    download_holding=True,
    download_settle=True,
    download_option=True,
):
    logger.info(
        "历史数据下载：%s - %s",
        start_date, end_date
    )

    if download_daily:
        fetch_fut_daily_range(start_date, end_date)

    if download_adj:
        fetch_fut_daily_adj_range(start_date, end_date)

    if download_mapping:
        fetch_fut_mapping(start_date, end_date)

    if download_wsr:
        fetch_fut_wsr(start_date, end_date)

    if download_holding:
        fetch_fut_holding(start_date, end_date)

    if download_settle:
        fetch_fut_settle(start_date, end_date)

    if download_option:
        fetch_option_daily_range(start_date, end_date)

    logger.info("历史数据库下载完成")


def update_one_day(trade_date):
    logger.info("=" * 60)
    logger.info("更新交易日：%s", trade_date)
    logger.info("=" * 60)

    fetch_fut_daily_by_date(trade_date)
    fetch_fut_daily_adj_by_date(trade_date)

    df = safe_api_call(
        pro.fut_mapping,
        trade_date=trade_date,
    )

    if not df.empty:
        save_csv(
            df,
            MAPPING_DIR / f"{trade_date}.csv",
        )

    df = safe_api_call(
        pro.fut_wsr,
        trade_date=trade_date,
    )

    if not df.empty:
        save_csv(
            df,
            WAREHOUSE_DIR / f"{trade_date}.csv",
        )

    fetch_fut_holding(trade_date, trade_date)
    fetch_fut_settle(trade_date, trade_date)
    fetch_option_daily_by_date(trade_date)

    logger.info(
        "交易日 %s 更新完成",
        trade_date
    )


if __name__ == "__main__":

    print(
        "\n"
        "中国商品期货数据系统\n"
        "====================\n"
    )

    # 先测试接口，不直接大批量下载历史数据
    test_df = safe_api_call(
        pro.fut_daily,
        trade_date="20260908",
        exchange="DCE",
    )

    print(test_df.head())
    print("\n共获取：", len(test_df), "条数据")

    # 首次正式运行时再解除下面注释
    #
    # init_database()
    #
    # download_history(
    #     start_date="20200101",
    #     end_date="20260908",
    # )
